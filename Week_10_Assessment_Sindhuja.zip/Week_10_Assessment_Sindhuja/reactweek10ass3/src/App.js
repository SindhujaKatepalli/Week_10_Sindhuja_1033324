import React from "react";
import logo from './logo.svg';
import './App.css';
 
class App extends React.Component{
    render(){
        return(
            <div className="bgcolor">
               
      <header className="App" >
        <img src={logo} className="App-logo" alt="logo" /><h3>React</h3>
      </header>
                <img src="https://raw.githubusercontent.com/codebucks27/React-Loading-Screen/main/loader3.png" height="250" width="600" align="center"></img>
                </div>
           
        );
    }
}
export default App