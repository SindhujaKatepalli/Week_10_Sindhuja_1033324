import './App.css';
import Regval from './Regval';
function App() {
  return (
    
    <Regval/>
  );
}
export default App;
